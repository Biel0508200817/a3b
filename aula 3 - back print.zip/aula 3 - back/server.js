const http = require('http');
const colors = require('colors'); 
const fs = require('fs');
const path = require('path');

// Dados para a Parte 3 do exercício
const dadosHardware = [
    { id: 1, produto: "Placa de Vídeo RTX 4060", preco: "R$ 2.100,00" },
    { id: 2, produto: "Processador Ryzen 7 5700X", preco: "R$ 1.200,00" },
    { id: 3, produto: "Memória RAM 16GB DDR4", preco: "R$ 350,00" },
];

const server = http.createServer((req, res) => {
    // Rota Principal (Home)
    if (req.url === '/') {
        const filePath = path.join(__dirname, 'public', 'index.html');
        
        fs.readFile(filePath, (err, content) => {
            if (err) {
                res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
                res.end('Erro: Certifique-se de que o arquivo index.html está dentro da pasta public.');
            } else {
                res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                res.end(content);
            }
        });
    } 
    // Rota da API (Exigência do exercício)
    else if (req.url === '/api/hardware') {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify(dadosHardware));
    } 
    // Rota 404
    else {
         const path404 = path.join(__dirname, 'public', '404.html');

          fs.readFile(path404, (err, content) => {
            if (err) {
                res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
                res.end('Página não encontrada(404)');
            } else {
               res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
                res.end(content);
            }
        });

        
    }
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`=== SERVIDOR ATIVO ===`.cyan);
    console.log(`Loja de Hardware rodando em: http://localhost:${PORT}`.green.bold);
    console.log(`API disponível em: http://localhost:${PORT}/api/hardware`.yellow);
});